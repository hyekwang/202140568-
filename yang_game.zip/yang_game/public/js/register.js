﻿// register.js - 회원가입 페이지

window.addEventListener("load", () => {
    const idInput = document.getElementById("reg-id");
    const pwInput = document.getElementById("reg-password");
    const nickInput = document.getElementById("reg-nickname");
    const btnReg = document.getElementById("btn-register");
    const msg = document.getElementById("reg-msg");

    async function doRegister() {
        const id = idInput.value.trim();
        const pw = pwInput.value.trim();
        const nick = nickInput.value.trim();

        if (!id || !pw || !nick) {
            msg.textContent = "ID / 비밀번호 / 닉네임을 모두 입력하세요.";
            return;
        }

        try {
            const res = await fetch("/auth", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ id, password: pw, nickname: nick, mode: "register" }),
            });
            const data = await res.json();
            if (!data.ok) {
                msg.textContent = data.msg || "회원가입 실패";
                return;
            }

            msg.textContent = "회원가입 성공! 로그인 페이지로 이동합니다.";
            setTimeout(() => {
                location.href = "/login";
            }, 800);
        } catch (e) {
            console.error(e);
            msg.textContent = "서버 오류";
        }
    }

    if (btnReg) btnReg.onclick = doRegister;

    nickInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
            e.preventDefault();
            doRegister();
        }
    });
});
