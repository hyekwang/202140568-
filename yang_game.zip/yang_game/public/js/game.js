// ===============================
//  양세찬 게임 - game.html 전용 스크립트
//  - WS 연결
//  - 질문/답변/정답 액션
//  - 중앙 채팅(질문/답변 vs 전체채팅) 토글
//  - 전체 채팅 전송/수신
// ===============================

let ws = null;
let nickname = null;
let roomId = null;
let currentActionMode = "ask"; // 기본값: 질문
let currentPlayers = [];       // 현재 방 플레이어 목록
let roundTimerInterval = null; // 라운드 시간
const myNick = localStorage.getItem("yg_nickname");

// ===== 유틸: DOM =====
function $(id) {
    return document.getElementById(id);
}

// ===== 유틸: 쿼리스트링 파싱 (친구 코드용) =====
function getQueryParams() {
    const params = new URLSearchParams(window.location.search);
    return {
        nickname: params.get("nickname") || "",
        roomId: params.get("roomId") || "",
        category: params.get("category") || "전체",
    };
}

// ===== UI 초기 세팅 =====
function initBasicInfo() {
    // 1) localStorage 우선
    const lsNick = localStorage.getItem("yg_nickname") || "";
    const lsRoom = localStorage.getItem("yg_roomId") || "";
    const lsCat = localStorage.getItem("yg_categoryLabel") || "";

    const qp = getQueryParams();
    nickname = lsNick || qp.nickname;
    roomId = lsRoom || qp.roomId;
    const category = lsCat || qp.category || "전체";

    // 헤더 오른쪽
    if ($("player-name-label")) $("player-name-label").textContent = nickname || "-";
    if ($("room-id-label")) $("room-id-label").textContent = roomId || "-";

    // 왼쪽 정보 박스
    if ($("room-id-info")) $("room-id-info").textContent = roomId || "-";
    if ($("my-nickname-label")) $("my-nickname-label").textContent = nickname || "-";
    if ($("category-info")) $("category-info").textContent = category || "전체";
    if ($("current-player-count")) $("current-player-count").textContent = "0";
    if ($("role-label")) $("role-label").textContent = "일반";
}

// ====== 로그 출력 유틸 ======
function appendSystemLog(text) {
    const el = $("game-log"); // 오른쪽 상단 로그 textarea
    if (!el) return;
    el.value += text + "\n";
    el.scrollTop = el.scrollHeight;
}

function appendSideChat(text) {
    const el = $("reaction-log"); // 오른쪽 하단 리액션 로그
    if (!el) return;
    el.value += text + "\n";
    el.scrollTop = el.scrollHeight;
}

function appendQaChat(text) {
    const el = $("qa-chat-log");
    if (!el) return;
    el.value += text + "\n";
    el.scrollTop = el.scrollHeight;
}

function appendGlobalChat(text) {
    const el = $("global-chat-log");
    if (!el) return;
    el.value += text + "\n";
    el.scrollTop = el.scrollHeight;
}

// ===== 플레이어 리스트 렌더링 =====
function renderPlayerList(payload) {
    const box = document.getElementById("player-list");
    if (!box) return;
    box.innerHTML = "";

    if (!payload) return;

    const items = payload.split(";");
    let count = 0;

    items.forEach((item) => {
        if (!item) return;
        // nick,ready,host 형식
        const [nick, ready, host] = item.split(",");
        count++;

        const row = document.createElement("li");
        row.className = "player-list-item";

        const left = document.createElement("div");
        left.textContent = nick === nickname ? nick + " (나)" : nick;

        const right = document.createElement("div");
        right.style.fontSize = "11px";
        right.style.color = "var(--muted)";
        right.textContent =
            `준비:${ready === "1" ? "O" : "X"} / ` +
            `방장:${host === "1" ? "O" : "X"}`;

        row.appendChild(left);
        row.appendChild(right);
        box.appendChild(row);
    });

    // 방 인원 표시 업데이트
    const countEl = document.getElementById("current-player-count");
    if (countEl) countEl.textContent = String(count);
}

// 닉네임 select 갱신 (질문 대상)
function refreshAskToSelect(arr) {
    const sel = $("ask-to-select");
    if (!sel) return;

    const prev = sel.value;
    sel.innerHTML =
        '<option value="">질문 대상 닉네임 선택</option>';

    const myNick = nickname;  // 이 파일 상단에서 이미 nickname 세팅함

    (arr || currentPlayers).forEach((nick) => {
        if (nick === myNick) return;

        const opt = document.createElement("option");
        opt.value = nick;
        opt.textContent = nick;
        sel.appendChild(opt);
    });

    if (prev) sel.value = prev;
}

// ===== 제시어 박스 제어 =====
function updatePromptBox(pos, text) {
    if (pos === "TOP" && $("prompt-top-box")) {
        $("prompt-top-box").style.display = text ? "inline-flex" : "none";
        $("prompt-top-box").textContent = text;
    }
    if (pos === "LEFT" && $("prompt-left-box")) {
        $("prompt-left-box").style.display = text ? "inline-flex" : "none";
        $("prompt-left-box").textContent = text;
    }
    if (pos === "RIGHT" && $("prompt-right-box")) {
        $("prompt-right-box").style.display = text ? "inline-flex" : "none";
        $("prompt-right-box").textContent = text;
    }
}

function clearPromptBoxes() {
    ["prompt-top-box", "prompt-left-box", "prompt-right-box"].forEach((id) => {
        const el = $(id);
        if (!el) return;
        el.style.display = "none";
        el.textContent = "";
    });
}

// ===== textarea 자동 높이 조절 =====
function autoResizeTextarea(el, maxHeight = 160) {
    if (!el) return;
    el.style.overflowY = "hidden";
    el.style.height = "auto";
    const h = Math.min(el.scrollHeight, maxHeight);
    el.style.height = h + "px";
    if (el.scrollHeight > maxHeight) {
        el.style.overflowY = "auto";
    } else {
        el.style.overflowY = "hidden";
    }
}

// ===== 서버 메시지 처리 =====
function handleWsMessage(raw) {
    console.log("WS MSG:", raw);  // ← 이 줄 추가

    const parts = String(raw).split("|");
    const type = parts[0];

    switch (type) {
        case "SYSTEM": {
            const text = parts.slice(1).join("|");
            appendSystemLog(text);

            // 질문/답변 관련 안내 문구면 중앙 Q&A에도 한 줄 남겨 주기
            if (text.includes("질문") || text.includes("정답") || text.includes("턴")) {
                appendQaChat(`[안내] ${text}`);
            }
            break;
        }

        // ▼ 우리가 추가: server.js의 ROOM_USER_LIST 처리
        case "ROOM_USER_LIST": {
            const payload = parts[1] || "";
            renderPlayerList(payload);
            // 질문 대상 셀렉트는 단순 닉 배열 필요하므로 한 번 더 추출
            const items = payload
                .split(";")
                .filter(Boolean)
                .map((item) => item.split(",")[0]);
            currentPlayers = items;
            refreshAskToSelect(items);
            break;
        }

        // 친구 코드에서 쓰던 PLAYER_LIST는 현재 server.js에 없으므로 일단 보류
        // case "PLAYER_LIST": { ... }

        case "INFO": {
            // INFO|key|value (예: INFO|ROLE|방장)
            const key = parts[1];
            const val = parts.slice(2).join("|");
            if (key === "ROLE" && $("role-label")) {
                $("role-label").textContent = val;
            }
            if (key === "PLAYER_COUNT" && $("current-player-count")) {
                $("current-player-count").textContent = val;
            }
            if (key === "TURN" && $("current-turn-label")) {
                $("current-turn-label").textContent = `현재 턴: ${val}`;
            }
            break;
        }

        case "ROUND": {
            const left = parseInt(parts[1] || "0", 10);
            const qcnt = parts[2] || "0";

            const secEl = $("round-remaining-seconds");
            const qEl = $("round-question-count");

            if (secEl) secEl.textContent = left;
            if (qEl) qEl.textContent = qcnt;

            // 이전 타이머 정리
            if (roundTimerInterval) {
                clearInterval(roundTimerInterval);
                roundTimerInterval = null;
            }

            // 새 타이머 시작 (30 → 29 → 28 … 1초마다 감소)
            if (secEl && left > 0) {
                let remain = left;
                roundTimerInterval = setInterval(() => {
                    remain -= 1;
                    if (remain <= 0) {
                        remain = 0;
                        clearInterval(roundTimerInterval);
                        roundTimerInterval = null;
                    }
                    secEl.textContent = remain;
                }, 1000);
            }
            break;
        }

        case "QA_CHAT": {
            const msg = parts.slice(2).join("|");
            appendQaChat(msg);

            break;
        }

        case "GLOBAL_CHAT": {
            const nick = parts[1] || "";
            const msg = parts.slice(2).join("|");
            appendGlobalChat(`[${nick}] ${msg}`);

            if (!isGlobalChatActive()) {
                setChatIcon(true);
            }
            break;
        }

        case "SIDE_CHAT": {
            appendSideChat(parts.slice(1).join("|"));
            break;
        }

        case "PROMPT": {
            const pos = parts[1];
            const text = parts.slice(2).join("|");
            updatePromptBox(pos, text);
            break;
        }

        case "PROMPT_CLEAR": {
            clearPromptBoxes();
            break;
        }

        case "BACK_TO_WAITING": {
            const room = parts[1] || roomId;
            window.location.href = `/waiting.html?nickname=${encodeURIComponent(
                nickname
            )}&roomId=${encodeURIComponent(room)}`;
            break;
        }

        // ▼ 우리가 추가: server.js에서 직접 오는 ASK / ANS / RESULT / TURN
        case "TURN": {
            const currentTurn = parts[1] || "-";
            console.log("TURN MSG:", currentTurn, "my nickname:", nickname);
            const turnLabel = document.getElementById("current-turn-label");
            if (turnLabel) turnLabel.textContent = "현재 턴: " + currentTurn;
            break;
        }

        case "WORDLIST": {
            const data = parts[1] || "";
            localStorage.setItem("yg_wordList", data);
            break;
        }

        case "ASK": {
            break;
        }

        case "ANS": {
            break;
        }

        case "RESULT": {
            break;
        }

        case "GAME_OVER": {
            const reason = parts[1] || "";
            const winnerName = parts[2] || "";

            if (reason === "ALL_CLEAR") {
                if (winnerName) {
                    alert(
                        `================
                    게임이 끝났습니다!
                    승자 : ${winnerName}
                    ================`
                    );
                } else {
                    alert("게임이 끝났습니다! (승자 정보 없음)");
                }
            }  else if (reason === "TIMEOUT") {
                alert("시간 초과로 게임이 종료되었습니다.");
            } else {
                alert(`게임이 끝났습니다!`);
            }

            setTimeout(() => {
                window.location.href = "waiting.html";
            }, 500);

            break;
        }



        default:
            appendSystemLog(raw);
            break;
    }
}
function setActionInputEnabled(enabled) {
    const bodyInput = $("game-action-input");
    if (!bodyInput) return;
    bodyInput.disabled = !enabled;
    bodyInput.placeholder = enabled
        ? "질문 / 답변 / 정답 내용을 입력하세요."
        : "지금은 입력할 수 없는 상태입니다.";
}


// ===== WS 연결 =====
function connectWs() {
    const url =
        (location.protocol === "https:" ? "wss://" : "ws://") + location.host;
    ws = new WebSocket(url);

    ws.onopen = () => {
        appendSystemLog("[SYSTEM] 서버에 연결되었습니다. 방에 입장 시도 중...");

        console.log("WS OPEN - nickname:", nickname, "roomId:", roomId);  // ← 이 줄 추가

        if (!nickname || !roomId) {
            appendSystemLog(
                "[SYSTEM] 닉네임 또는 방 정보가 없습니다. 다시 접속해 주세요."
            );
            if (ws && ws.readyState === WebSocket.OPEN) {
                ws.close();
            }
            return;
        }
        ws.send(`JOIN|${nickname}`);
        ws.send(`JOIN_ROOM|${roomId}`);

        console.log("SENT: JOIN + JOIN_ROOM");  // ← 이 줄 추가
    };

    ws.onclose = () => {
        appendSystemLog("[SYSTEM] 서버와의 연결이 종료되었습니다.");
    };

    ws.onerror = (e) => {
        console.error(e);
        appendSystemLog("[SYSTEM] 오류가 발생했습니다. 콘솔을 확인해 주세요.");
    };

    ws.onmessage = (event) => {
        handleWsMessage(event.data);
    };
}

// ===== 질문/답변/정답 전송 =====
function initGameActionForm() {
    const modeHidden = $("game-action-mode"); // hidden input
    const modePills = document.querySelectorAll(".mode-pill");
    const askToSelect = $("ask-to-select");
    const bodyInput = $("game-action-input");
    const sendBtn = $("send-game-action-btn");

    if (bodyInput) {
        bodyInput.addEventListener("input", () => autoResizeTextarea(bodyInput));
        autoResizeTextarea(bodyInput);
    }

    modePills.forEach((btn) => {
        btn.addEventListener("click", () => {
            const mode = btn.dataset.mode; // ask / ans / guess
            if (!mode) return;
            currentActionMode = mode;
            if (modeHidden) modeHidden.value = mode;

            modePills.forEach((b) => b.classList.remove("active"));
            btn.classList.add("active");
        });
    });

    function sendGameAction() {
        if (!ws || ws.readyState !== WebSocket.OPEN) {
            appendSystemLog("[SYSTEM] 서버와 연결되지 않았습니다.");
            return;
        }
        if (!bodyInput) return;

        const mode = currentActionMode; // ask / ans / guess
        const targetNick = askToSelect ? askToSelect.value.trim() : "";
        const body = bodyInput.value.trim();
        if (!body) return;

        const turnLabel = $("current-turn-label");
        const currentTurnText = turnLabel ? turnLabel.textContent.replace("현재 턴: ", "").trim() : "";
        const isMyTurn = currentTurnText === nickname;

        if ((mode === "ask" || mode === "guess") && !isMyTurn) {
            appendQaChat("[안내] 지금은 당신의 턴이 아닙니다.");
            return;
        }

        if (mode === "ask") {
            if (!targetNick) {
                appendSystemLog("[SYSTEM] 질문 대상 닉네임을 선택하세요.");
                return;
            }
            // ASK|to|question
            ws.send(`ASK|${targetNick}|${body}`);
        } else if (mode === "ans") {
            // ANS|answer
            ws.send(`ANS|${body}`);
        } else if (mode === "guess") {
            // GUESS|guessText
            ws.send(`GUESS|${body}`);
        }

        // server.js의 GAME_ACTION 처리에 맞춤
        ws.send(`GAME_ACTION|${mode}|${nickname}|${targetNick}|${body}`);

        bodyInput.value = "";
        autoResizeTextarea(bodyInput);
    }

    if (sendBtn) sendBtn.addEventListener("click", sendGameAction);
    if (bodyInput) {
        bodyInput.addEventListener("keydown", (e) => {
            if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                sendGameAction();
            }
        });
    }
}

// ===== 중앙 채팅 모드: QA vs GLOBAL =====
function initCenterChatToggle() {
    const qaPanel = $("qa-chat-panel");
    const globalPanel = $("global-chat-panel");
    const toggleBtn = $("toggle-global-chat-btn");
    const centerTitle = document.querySelector(".center-chat-title");
    const centerSub = document.querySelector(".center-chat-sub");

    let isGlobalChatMode = false;

    function applyMode() {
        if (!qaPanel || !globalPanel) return;

        if (isGlobalChatMode) {
            qaPanel.classList.remove("active");
            globalPanel.classList.add("active");
            if (centerTitle) centerTitle.textContent = "전체 채팅";
            if (centerSub)
                centerSub.textContent =
                    "모든 플레이어가 자유롭게 수다를 떨 수 있는 채팅입니다.";
        } else {
            qaPanel.classList.add("active");
            globalPanel.classList.remove("active");
            if (centerTitle) centerTitle.textContent = "질문 / 답변 채팅";
            if (centerSub)
                centerSub.textContent =
                    "질문자는 특정 인물을 선택한 뒤 질문을 남기고, 답변을 받습니다.";
        }
        // 전체채팅 패널을 보고 있을 때는 항상 파란색
        if (isGlobalChatMode) {
            setChatIcon(false);
        }
    }

    if (toggleBtn) {
        toggleBtn.addEventListener("click", () => {
            isGlobalChatMode = !isGlobalChatMode;
            applyMode();
        });
    }

    if (qaPanel) qaPanel.classList.add("active");
    applyMode();
}

// ===== 전체 채팅 입력/전송 =====
function initGlobalChatForm() {
    const input = $("global-chat-input");
    const btn = $("global-chat-send-btn");

    function sendGlobalChat() {
        if (!ws || ws.readyState !== WebSocket.OPEN) {
            appendSystemLog("[SYSTEM] 서버와 연결되지 않았습니다.");
            return;
        }
        if (!input) return;

        const msg = (input.value || "").trim();
        if (!msg) return;

        ws.send(`GLOBAL_CHAT|${nickname}|${msg}`);
        appendGlobalChat(`[${nickname}] ${msg}`);
        input.value = "";
        autoResizeTextarea(input);
    }

    if (input) {
        input.addEventListener("input", () => autoResizeTextarea(input));
        autoResizeTextarea(input);

        input.addEventListener("keydown", (e) => {
            if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                sendGlobalChat();
            }
        });
    }

    if (btn) btn.addEventListener("click", sendGlobalChat);
}
// ===== 채팅 아이콘 제어 =====
function isGlobalChatActive() {
    const panel = $("global-chat-panel");
    return panel && panel.classList.contains("active");
}

function setChatIcon(hasUnread) {
    const icon = $("chat_icon");
    if (!icon) return;
    icon.src = hasUnread ? "/img/chat_icon_red.png" : "/img/chat_icon_blue.png";
}


// ===== 방 나가기 버튼 =====
function initLeaveButton() {
    const btn = $("leave-room-btn");
    if (!btn) return;
    btn.addEventListener("click", () => {
        if (ws && ws.readyState === WebSocket.OPEN) {
            ws.send(`LEAVE_ROOM`);
        }
        window.location.href = "/room.html";
    });
}

// ===== DOMContentLoaded =====
document.addEventListener("DOMContentLoaded", () => {
    initBasicInfo();
    connectWs();
    initGameActionForm();
    initCenterChatToggle();
    initGlobalChatForm();
    initLeaveButton();
});
