﻿// login.js - 로그인 페이지

window.addEventListener("load", () => {
    const idInput = document.getElementById("login-id");
    const pwInput = document.getElementById("login-password");
    const btnLogin = document.getElementById("btn-login");
    const msg = document.getElementById("login-msg");

    async function doLogin() {
        const id = idInput.value.trim();
        const pw = pwInput.value.trim();
        if (!id || !pw) {
            msg.textContent = "ID와 비밀번호를 입력하세요.";
            return;
        }

        try {
            const res = await fetch("/auth", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ id, password: pw, mode: "login" }),
            });
            const data = await res.json();
            if (!data.ok) {
                msg.textContent = data.msg || "로그인 실패";
                return;
            }

            const nickname = data.nickname;
            localStorage.setItem("yg_nickname", nickname);
            msg.textContent = "로그인 성공! 로비로 이동합니다...";

            // 바로 room.html 로 이동
            setTimeout(() => {
                location.href = "/room.html";
            }, 500);
        } catch (e) {
            console.error(e);
            msg.textContent = "서버 오류";
        }
    }

    if (btnLogin) btnLogin.onclick = doLogin;

    pwInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
            e.preventDefault();
            doLogin();
        }
    });
});
