// main.js - 닉네임 입력 화면에서 동작하는 스크립트
// 역할:
//  - 로컬스토리지에 저장된 닉네임 불러오기
//  - 닉네임 입력 후 "JOIN" 버튼 또는 Enter로 방 선택 화면(room.html)으로 이동

window.addEventListener("load", () => {
  // 닉네임 입력창, 버튼, 안내 메시지 DOM 요소 가져오기
  const nickInput = document.getElementById("nickname-input");
  const joinBtn = document.getElementById("btn-set-nickname");
  const msg = document.getElementById("main-msg");

  // 이전에 접속한 적이 있다면, 저장된 닉네임 불러와서 기본값으로 넣어줌
  const savedNick = localStorage.getItem("yg_nickname");
  if (savedNick && nickInput) {
    nickInput.value = savedNick;
  }

  // 요소가 없으면 더 이상 진행할 수 없으므로 종료
  if (!joinBtn || !nickInput) return;

  // 닉네임 설정 후 로비(방 선택 화면)로 이동하는 함수
  function doJoin() {
    const nick = nickInput.value.trim();
    if (!nick) {
      alert("닉네임을 입력하세요.");
      return;
    }

    // 브라우저 로컬스토리지에 닉네임 저장
    localStorage.setItem("yg_nickname", nick);

    // 하단 안내 텍스트 변경
    if (msg) msg.textContent = "로비로 이동 중...";

    // 방 선택 화면으로 이동
    location.href = "/room.html";
  }

  // 버튼 클릭 시 닉네임 설정 + 페이지 이동
  joinBtn.onclick = doJoin;

  // Enter 키로도 바로 JOIN 되도록 설정
  nickInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      doJoin();
    }
  });
});
