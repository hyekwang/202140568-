// waiting.js - 대기실 화면

let ws = null;
let nickname = null;
let roomId = null;
let isHost = false;

// 제시어 관련
let promptSubmitted = false;
let promptStatusEl = null;

// 플레이어 목록
let currentPlayers = [];

// 자동 게임 시작 중복 방지
let autoGameStartRequested = false;

// =================== 공통 로그 유틸 ===================
function logSystem(text) {
  const box = document.getElementById("waiting-chat-log");
  if (!box) return;
  const div = document.createElement("div");
  div.textContent = "[SYSTEM] " + text;
  box.appendChild(div);
  box.scrollTop = box.scrollHeight;
}

function logChat(text) {
  const box = document.getElementById("waiting-chat-log");
  if (!box) return;
  const div = document.createElement("div");
  div.textContent = text;
  box.appendChild(div);
  box.scrollTop = box.scrollHeight;
}

// =================== 플레이어 목록 / 준비현황 ===================
function renderPlayerList(payload) {
  const container = document.getElementById("wait-player-list");
  if (!container) return;
  container.innerHTML = "";

  currentPlayers = [];

  if (!payload) return;

  const items = payload.split(";");
  let readyCount = 0;

  items.forEach((item) => {
    if (!item) return;
    // 형식 예: nick,ready,host
    const [nick, ready, host] = item.split(",");
    currentPlayers.push({ nick, ready, host});

    if (ready === "1") readyCount++;

    const row = document.createElement("div");
    row.className = "player-list-item";

    const left = document.createElement("div");
    left.textContent = nick === nickname ? nick + " (나)" : nick;

    const right = document.createElement("div");
    right.style.fontSize = "11px";
      right.textContent =
          `준비:${ready === "1" ? "O" : "X"} / ` +
          `방장:${host === "1" ? "O" : "X"}`;

    row.appendChild(left);
    row.appendChild(right);
    container.appendChild(row);

    if (nick === nickname) {
      isHost = host === "1";
      const roleSpan = document.getElementById("wait-role");
      if (roleSpan) roleSpan.textContent = isHost ? "HOST" : "PLAYER";
    }
  });

  // 준비 요약 문구
  const readySummary = document.getElementById("ready-summary");
  if (readySummary) {
    readySummary.textContent = `준비 인원: ${readyCount} / ${currentPlayers.length}`;
  }

  // 제시어 대상 셀렉트 갱신 (본인은 제외)
  const sel = document.getElementById("prompt-target");
  if (sel) {
    sel.innerHTML = "";
    currentPlayers.forEach((p) => {
      if (p.nick === nickname) return;
      const opt = document.createElement("option");
      opt.value = p.nick;
      opt.textContent = p.nick;
      sel.appendChild(opt);
    });
  }
}

// =================== 서버 메시지 처리 ===================
function handleMessage(line) {
  const parts = line.split("|");
  const cmd = parts[0];

  switch (cmd) {
    case "NICK_OK": {
      const newNick = parts[1] || "";
      if (newNick) {
        nickname = newNick;
        localStorage.setItem("yg_nickname", newNick);
        const ids = ["wait-nickname", "left-nickname", "center-nickname"];
        ids.forEach((id) => {
          const el = document.getElementById(id);
          if (el) el.textContent = newNick;
        });
      }
      break;
    }

    case "SYSTEM": {
      const text = parts.slice(1).join("|");
      logSystem(text);
      break;
    }

    // 방/카테고리 정보
    case "ROOM_INFO": {
      // 예: ROOM_INFO|roomId|categoryCode|categoryLabel
      roomId = parts[1] || roomId;
      const catCode = parts[2] || "";
      const catLabel = parts[3] || "전체";

      if (roomId) {
        localStorage.setItem("yg_roomId", roomId);
        ["wait-room-id", "left-room-id", "center-room-id"].forEach((id) => {
          const el = document.getElementById(id);
          if (el) el.textContent = roomId;
        });
      }

      localStorage.setItem("yg_categoryCode", catCode);
      localStorage.setItem("yg_categoryLabel", catLabel);

      const ids = ["category-label", "center-category"];
      ids.forEach((id) => {
        const el = document.getElementById(id);
        if (el) el.textContent = catLabel;
      });
      break;
    }

    // 방 안 플레이어 목록
    case "ROOM_USER_LIST": {
      renderPlayerList(parts[1] || "");
      break;
    }

    // 제시어가 정상적으로 등록되었을 때
    case "PROMPT_SET": {
      const who = parts[1];
      if (who === nickname) {
        promptSubmitted = true;
        if (promptStatusEl) {
          promptStatusEl.textContent =
            "내 제시어 전송 완료! 다른 플레이어들을 기다리는 중입니다.";
        }
      } else {
        logSystem(`${who} 님의 제시어 입력 완료.`);
      }
      break;
    }

    // 아직 제시어 안 넣은 사람들 목록
    case "PROMPT_STATUS": {
      const waitingRaw = parts[1] || "";
      const arr = waitingRaw
        ? waitingRaw.split(",").filter((x) => x)
        : [];
      if (!promptStatusEl) break;

      if (arr.length === 0) {
        // 모든 제시어 입력 완료
        promptStatusEl.textContent =
          "모든 플레이어의 제시어가 설정되었습니다. 곧 게임이 시작됩니다.";

        // ✅ 방장 클라이언트가 자동으로 게임 시작 요청
        if (
          isHost &&
          !autoGameStartRequested &&
          ws &&
          ws.readyState === WebSocket.OPEN
        ) {
          autoGameStartRequested = true;
          logSystem("모든 제시어가 완료되어 게임을 자동으로 시작합니다.");
          // 살짝 딜레이를 주면 WORDLIST 같은 추가 메시지가 먼저 도착할 시간을 줄 수 있음
          setTimeout(() => {
            if (ws && ws.readyState === WebSocket.OPEN) {
              ws.send("START_GAME");
            }
          }, 700);
        }
      } else {
        promptStatusEl.textContent =
          "아직 제시어를 입력하지 않은 플레이어: " + arr.join(", ");
      }
      break;
    }

    // 서버가 미리 전체 제시어 리스트를 보내줄 때
    case "WORDLIST": {
      const data = parts[1] || "";
      localStorage.setItem("yg_wordList", data);
      break;
    }

    // 대기실 채팅
    case "CHAT": {
      const from = parts[1];
      const msg = parts.slice(2).join("|");
      logChat(`[${from}] ${msg}`);
      break;
    }

    // 게임 시작 신호
    case "GAME_START": {
      logSystem("게임이 시작됩니다. 게임 화면으로 이동합니다.");
      setTimeout(() => {
        location.href = "/game.html";
      }, 800);
      break;
    }

    // 방 나가기 허용
    case "LEAVE_ROOM_OK": {
      localStorage.removeItem("yg_roomId");
      localStorage.removeItem("yg_wordList");
      location.href = "/room.html";
      break;
    }

    case "KICKED": {
      alert("방에서 강제퇴장되었습니다.");
      localStorage.removeItem("yg_roomId");
      localStorage.removeItem("yg_wordList");
      location.href = "/room.html";
      break;
    }

    default: {
      console.log("unknown cmd:", cmd, parts);
    }
  }
}

// =================== WebSocket 연결 ===================
function connectWs() {
  const url =
    (location.protocol === "https:" ? "wss://" : "ws://") + location.host;
  ws = new WebSocket(url);

  ws.onopen = () => {
    console.log("WS connected on waiting.html");

    if (!nickname) {
      nickname = localStorage.getItem("yg_nickname");
    }
    if (!roomId) {
      roomId = localStorage.getItem("yg_roomId");
    }

    if (!nickname || !roomId) {
      alert("닉네임 또는 방 정보가 없습니다. 처음 화면으로 돌아갑니다.");
      location.href = "/room.html";
      return;
    }

    // 헤더 / 좌측 / 중앙에 기본 값 세팅
    ["wait-nickname", "left-nickname", "center-nickname"].forEach((id) => {
      const el = document.getElementById(id);
      if (el) el.textContent = nickname;
    });
    ["wait-room-id", "left-room-id", "center-room-id"].forEach((id) => {
      const el = document.getElementById(id);
      if (el) el.textContent = roomId;
    });

    const catLabel = localStorage.getItem("yg_categoryLabel");
    if (catLabel) {
      const ids = ["category-label", "center-category"];
      ids.forEach((id) => {
        const el = document.getElementById(id);
        if (el) el.textContent = catLabel;
      });
    }

    ws.send(`JOIN|${nickname}`);
    ws.send(`JOIN_ROOM|${roomId}`);

    logSystem("서버에 연결되었습니다. 닉네임/방 정보를 동기화 중입니다.");
  };

  ws.onmessage = (event) => {
    const line = event.data;
    if (!line) return;
    handleMessage(line);
  };

  ws.onclose = () => {
    console.log("WS closed on waiting.html");
    logSystem("서버와의 연결이 종료되었습니다.");
  };

  ws.onerror = (err) => {
    console.error("WS error:", err);
    logSystem("WebSocket 오류가 발생했습니다.");
  };
}

// =================== 이벤트 바인딩 ===================
window.addEventListener("load", () => {
  nickname = localStorage.getItem("yg_nickname") || "";
  roomId = localStorage.getItem("yg_roomId") || "";

  promptStatusEl = document.getElementById("prompt-status");

  connectWs();

  // ---- 준비 / 준비 해제 ----
  const btnReady = document.getElementById("btn-ready");
  const btnReadyCancel = document.getElementById("btn-ready-cancel");

  if (btnReady) {
    btnReady.onclick = () => {
      if (!ws || ws.readyState !== WebSocket.OPEN) return;
      ws.send("READY|1");
    };
  }
  if (btnReadyCancel) {
    btnReadyCancel.onclick = () => {
      if (!ws || ws.readyState !== WebSocket.OPEN) return;
      ws.send("READY|0");
    };
  }

  // ---- 게임 시작 (방장 수동 시작 버튼 - 자동 시작이 있으니 옵션용) ----
  const btnStart = document.getElementById("btn-start-game");
  if (btnStart) {
    btnStart.onclick = () => {
      if (!ws || ws.readyState !== WebSocket.OPEN) return;
      if (!isHost) {
        alert("게임 시작은 방장만 가능합니다.");
        return;
      }
      if (autoGameStartRequested) {
        alert("이미 게임 시작이 진행 중입니다.");
        return;
      }
      ws.send("START_GAME");
    };
  }

  // ---- 방 나가기 ----
  const btnLeave = document.getElementById("btn-leave-room");
  if (btnLeave) {
    btnLeave.onclick = () => {
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send("LEAVE_ROOM");
      } else {
        localStorage.removeItem("yg_roomId");
        localStorage.removeItem("yg_wordList");
        location.href = "/room.html";
      }
    };
  }

  // ---- 방장 도구: 음소거 / 강퇴 ----
  const btnBan = document.getElementById("btn-ban");
  const banTargetInput = document.getElementById("ban-target-input");
  const btnAddBot = document.getElementById("btn-add-bot");


  if (btnBan) {
    btnBan.onclick = () => {
      if (!ws || ws.readyState !== WebSocket.OPEN) return;
      if (!isHost) {
        alert("강퇴는 방장만 사용할 수 있습니다.");
        return;
      }
      if (!banTargetInput) {
        alert("강퇴할 닉네임을 입력하세요.");
        return;
      }
      const target = banTargetInput.value.trim();
      if (!target) {
        alert("강퇴할 닉네임을 입력하세요.");
        return;
      }
      ws.send(`KICK|${target}`);
    };
    }

    if (btnAddBot) {
        btnAddBot.onclick = () => {
            if (!ws || ws.readyState !== WebSocket.OPEN) return;
            if (!isHost) {
                alert("봇 추가는 방장만 가능합니다.");
                return;
            }
            ws.send("ADD_BOT");
        };
    }

  // ---- 제시어 보내기 ----
  const btnPrompt = document.getElementById("btn-send-prompt");
  const promptTarget = document.getElementById("prompt-target");
  const promptInput = document.getElementById("prompt-word-input");

  function doSendPrompt() {
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    if (promptSubmitted) {
      alert("이미 제시어를 전송했습니다. 수정이 필요하면 방장에게 문의하세요.");
      return;
    }

    const target = promptTarget?.value || "";
    const word = promptInput?.value.trim() || "";

    if (!target) {
      alert("제시어를 줄 대상을 선택해주세요.");
      return;
    }
    if (!word) {
      alert("제시어 내용을 입력해주세요.");
      return;
    }

    ws.send(`SET_PROMPT|${target}|${word}`);
    promptSubmitted = true;
    if (promptInput) promptInput.value = "";
  }

  if (btnPrompt) btnPrompt.onclick = doSendPrompt;
  if (promptInput) {
    promptInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        doSendPrompt();
      }
    });
  }

  // ---- 대기실 채팅 ----
  const chatInput = document.getElementById("waiting-chat-input");
  const btnChat = document.getElementById("btn-waiting-chat");

  function doChat() {
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    if (!chatInput) return;
    const msg = chatInput.value.trim() || "";
    if (!msg) return;
    ws.send("CHAT|" + msg);
    chatInput.value = "";
  }

  if (btnChat) btnChat.onclick = doChat;
  if (chatInput) {
    chatInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        doChat();
      }
    });
  }
});
