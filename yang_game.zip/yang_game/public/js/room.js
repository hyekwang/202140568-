// room.js - 서버 / 방 선택 화면에서 동작하는 스크립트
// 역할:
//  - 서버와 WebSocket 연결
//  - 방 리스트 수신 및 렌더링
//  - 방 생성 요청, 방 입장 요청 처리
//  - 선택한 방 ID 표시 및 더블클릭으로 빠른 입장

let ws = null;             // 방 선택 화면에서 사용할 WebSocket 객체
let nickname = null;       // 현재 내 닉네임
let selectedRoomId = null; // 현재 리스트에서 선택된 방 ID

// 간단 로그 유틸
function log(...args) {
  console.log(...args);
}

// ================= WebSocket 연결 =================
function connectWs() {
  // 현재 호스트 기준으로 WebSocket 연결 (http/https 모두 대응)
  const url =
    (location.protocol === "https:" ? "wss://" : "ws://") + location.host;
  ws = new WebSocket(url);

  ws.onopen = () => {
    console.log("WS connected on room.html");

    // 1) 서버에 닉네임 등록
    // 2) 방 리스트 요청
    ws.send(`JOIN|${nickname}`);
    ws.send("ROOM_LIST_REQ");
  };

  ws.onmessage = (event) => {
    const line = event.data;
    if (!line) return;
    handleMessage(line);
  };

  ws.onclose = () => {
    console.log("WS closed on room.html");
  };

  ws.onerror = (err) => {
    console.error("WS error:", err);
  };
}

// ================= 서버 메시지 처리 =================
function handleMessage(line) {
  const parts = line.split("|");
  const cmd = parts[0];

  switch (cmd) {
    case "NICK_OK": {
      const newNick = parts[1] || "";
      if (newNick) {
        nickname = newNick;
        localStorage.setItem("yg_nickname", newNick);
        const sideNick = document.getElementById("wait-nickname-side");
        const spanNick = document.getElementById("wait-nickname");
        const headerNick = document.getElementById("header-nickname");
        if (sideNick) sideNick.textContent = newNick;
        if (spanNick) spanNick.textContent = newNick;
        if (headerNick) headerNick.textContent = newNick;
      }
      break;
    }

    case "SYSTEM": {
      const text = parts.slice(1).join("|");
      log("[SYSTEM] " + text);
      break;
    }

    // 전체 방 리스트 수신 → 화면에 렌더링
    case "ROOM_LIST": {
      const payload = parts[1] || "";
      renderRoomList(payload);
      break;
    }

    // 방 생성 성공 → 새로 만든 방의 ID를 로컬에 저장하고 대기실로 이동
    case "ROOM_CREATED": {
      const roomId = parts[1];
      localStorage.setItem("yg_roomId", roomId);
      localStorage.setItem("yg_isHost", "1"); // 방장은 isHost = 1
      location.href = "/waiting.html";
      break;
    }

    // 기존 방 입장 성공 → 방 ID 저장 후 대기실로 이동
    case "JOIN_ROOM_OK": {
      const roomId = parts[1];
      localStorage.setItem("yg_roomId", roomId);
      localStorage.setItem("yg_isHost", "0"); // 일반 유저
      location.href = "/waiting.html";
      break;
    }

    // 로비에서 강제 퇴장당한 경우
    case "KICKED": {
      alert("방에서 강제퇴장되었습니다.");
      localStorage.removeItem("yg_roomId");
      break;
    }

    default:
      console.log("Unknown command:", cmd, parts);
  }
}

// ================= 방 리스트 그리기 =================
// payload 예시: "1,양세찬,1/4,WAIT;2,테스트방,2/4,INGAME"
function renderRoomList(payload) {
  const ul = document.getElementById("room-list");
  const emptyMsg = document.getElementById("room-empty-msg");
  if (!ul) return;

  // 기존 리스트 비우기
  ul.innerHTML = "";

  // 방이 하나도 없을 때
  if (!payload) {
    if (emptyMsg) emptyMsg.style.display = "block";
    return;
  } else {
    if (emptyMsg) emptyMsg.style.display = "none";
  }

  // "방1;방2;방3..." 구조를 세미콜론으로 분리
  const rooms = payload.split(";").filter((x) => x);

  rooms.forEach((item) => {
    // "id,name,count,status" 순서
    const [id, name, count, status] = item.split(",");

    const li = document.createElement("li");
    li.className = "room-list-item";
    li.dataset.roomId = id;

    // 이미 선택해둔 방이 있다면 해당 li에 selected 클래스 유지
    if (selectedRoomId === id) {
      li.classList.add("selected");
    }

    // 왼쪽: 방 이름 / ID
    const left = document.createElement("div");
    left.className = "room-left";
    left.textContent = `ID:${id} | ${name}`;

    // 오른쪽: 인원 수 / 상태 표시
    const right = document.createElement("div");
    right.className = "room-right";

    const spanCount = document.createElement("span");
    spanCount.textContent = count; // 예: "1/4"
    spanCount.className = "room-count";

    const spanStatus = document.createElement("span");
    spanStatus.className =
      "room-status-tag " + (status === "INGAME" ? "ingame" : "wait");
    spanStatus.textContent = status === "INGAME" ? "게임 중" : "대기 중";

    right.appendChild(spanCount);
    right.appendChild(spanStatus);

    li.appendChild(left);
    li.appendChild(right);

    // 단일 클릭: 방 선택 + 아래 입력창에 ID 채우기
    li.onclick = () => {
      const joinInput = document.getElementById("join-room-id-input");
      selectedRoomId = id;
      if (joinInput) joinInput.value = id;

      // 다른 항목들은 selected 제거
      document
        .querySelectorAll(".room-list-item.selected")
        .forEach((el) => el.classList.remove("selected"));
      li.classList.add("selected");
    };

    // 더블클릭: 즉시 해당 방 입장 시도
    li.ondblclick = () => {
      if (typeof window.doJoin === "function") {
        window.doJoin(id);
      }
    };

    ul.appendChild(li);
  });
}

// ================= 페이지 로드시 초기화 =================
window.addEventListener("load", () => {
    nickname = localStorage.getItem("yg_nickname");

    // 프로필 닉네임 / 승리 횟수 표시
    const nickSpan = document.getElementById("profile-nick");
    const winSpan = document.getElementById("profile-win");
    if (nickSpan) nickSpan.textContent = nickname;

    if (winSpan) {
        fetch(`/profile?nickname=${encodeURIComponent(nickname)}`)
            .then((res) => res.json())
            .then((data) => {
                winSpan.textContent = `승리 횟수: ${data.win || 0}`;
            })
            .catch(() => {
                winSpan.textContent = "승리 횟수: 0";
            });
    }

  // 좌측 프로필에 닉네임 표시
  const sideNick = document.getElementById("side-nickname-room");
  if (sideNick) sideNick.textContent = nickname;

  // WebSocket 연결 시작
  connectWs();

  // 주요 버튼 / 입력창 DOM 요소
  const btnRefresh = document.getElementById("btn-refresh-rooms");
  const btnCreate = document.getElementById("btn-create-room");
  const btnJoin = document.getElementById("btn-join-room");

  const nameInput = document.getElementById("room-name-input");
  const maxInput = document.getElementById("room-max-input");
  const joinIdInput = document.getElementById("join-room-id-input");

  // 방 리스트 새로고침
  function doRefresh() {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send("ROOM_LIST_REQ");
    }
  }

  // 새 방 생성
  function doCreate() {
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    const name = (nameInput?.value || "").trim() || "방";
    const max = (maxInput?.value || "").trim() || "4";
    ws.send(`CREATE_ROOM|${name}|${max}`);
  }

  // 기존 방 입장 (idFromClick: 리스트 더블클릭으로 들어온 경우)
  function doJoin(idFromClick) {
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    const id = idFromClick || (joinIdInput?.value || "").trim();
    if (!id) {
      alert("입장할 방 ID를 선택하거나 입력하세요.");
      return;
    }
    ws.send(`JOIN_ROOM|${id}`);
  }

  // 다른 곳에서도 호출할 수 있게 전역에 노출 (예: li.ond블클릭에서 사용)
  window.doJoin = doJoin;

  // 버튼 클릭 이벤트 바인딩
  if (btnRefresh) btnRefresh.onclick = doRefresh;
  if (btnCreate) btnCreate.onclick = doCreate;
  if (btnJoin) btnJoin.onclick = () => doJoin();

  // Enter 키로도 동작하도록 이벤트 바인딩
  if (nameInput) {
    nameInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        doCreate();
      }
    });
  }

  if (maxInput) {
    maxInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        doCreate();
      }
    });
  }

  if (joinIdInput) {
    joinIdInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        doJoin();
      }
    });
  }
});
