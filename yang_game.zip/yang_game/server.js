// server.js
// - HTTP 서버: /public 폴더 정적 파일 서빙
// - WebSocket 서버: 양세찬 게임 (방, 턴, 질문/답변/정답, 시간 제한, 제시어 단계 등) 처리

const http = require("http");
const path = require("path");
const fs = require("fs");
const WebSocket = require("ws");
const db = require("./db");

const PORT = 3000;
const publicDir = path.join(__dirname, "public");

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
};

const {
    callGemini,
    pickRandomAnimalWordForPlayer,
    makeBotQuestion,
    makeBotAnswer,
    pickWordForCategory,
} = require("./bot");

// ----------------------------------------------------
// 1. HTTP 서버
// ----------------------------------------------------
const httpServer = http.createServer(async (req, res) => {
    // 0) /auth API 처리
    if (req.method === "POST" && req.url === "/auth") {
        let body = "";
        req.on("data", (chunk) => (body += chunk));
        req.on("end", async () => {
            try {
                const { id, nickname, password, mode } = JSON.parse(body || "{}");

                if (!id || !password || (mode === "register" && !nickname)) {
                    res.writeHead(400, { "Content-Type": "application/json" });
                    return res.end(
                        JSON.stringify({ ok: false, msg: "ID / 비밀번호 / 닉네임을 확인하세요." })
                    );
                }

                if (mode === "register") {
                    const exists = await db.findUserById(id);
                    if (exists) {
                        res.writeHead(400, { "Content-Type": "application/json" });
                        return res.end(JSON.stringify({ ok: false, msg: "이미 존재하는 ID입니다." }));
                    }
                    const nickExists = await db.findUserByNickname(nickname);
                    if (nickExists) {
                        res.writeHead(400, { "Content-Type": "application/json" });
                        return res.end(
                            JSON.stringify({ ok: false, msg: "이미 사용 중인 닉네임입니다." })
                        );
                    }
                    await db.createUser({ id, nickname, password });
                    res.writeHead(200, { "Content-Type": "application/json" });
                    return res.end(JSON.stringify({ ok: true }));
                }

                // mode === "login"
                const user = await db.findUserById(id);
                if (!user || user.password !== password) {
                    res.writeHead(400, { "Content-Type": "application/json" });
                    return res.end(
                        JSON.stringify({ ok: false, msg: "ID 또는 비밀번호가 올바르지 않습니다." })
                    );
                }

                res.writeHead(200, { "Content-Type": "application/json" });
                res.end(JSON.stringify({ ok: true, nickname: user.nickname }));
            } catch (e) {
                console.error("AUTH error:", e);
                res.writeHead(500, { "Content-Type": "application/json" });
                res.end(JSON.stringify({ ok: false, msg: "서버 오류" }));
            }
        });
        return;
    }

    // 1) 승리 횟수 조회 API (/profile?nickname=...)
    if (req.method === "GET" && req.url.startsWith("/profile")) {
        try {
            const urlObj = new URL(req.url, "http://dummy");
            const nickname = urlObj.searchParams.get("nickname") || "";
            const win = nickname ? await db.getWinCount(nickname) : 0;
            res.writeHead(200, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ win }));
        } catch (e) {
            console.error("PROFILE error:", e);
            res.writeHead(500, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ win: 0 }));
        }
        return;
    }

    // 2) 라우팅: /, /login, /register
    if (req.method === "GET") {
        let urlPath = req.url;
        if (urlPath === "/" || urlPath === "/login" || urlPath === "/login.html") {
            urlPath = "/login.html";
        } else if (urlPath === "/register" || urlPath === "/register.html") {
            urlPath = "/register.html";
        }

        const filePath = path.join(publicDir, urlPath);
        fs.readFile(filePath, (err, data) => {
            if (err) {
                res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
                res.end("404 Not Found");
                return;
            }
            const ext = path.extname(filePath);
            const mime = mimeTypes[ext] || "text/plain; charset=utf-8";
            res.writeHead(200, { "Content-Type": mime });
            res.end(data);
        });
        return;
    }

    // 3) 나머지 정적 파일 (room.html, waiting.html, js, css 등)
    const filePath = path.join(publicDir, req.url);
    fs.readFile(filePath, (err, data) => {
        if (err) {
            res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
            res.end("404 Not Found");
            return;
        }
        const ext = path.extname(filePath);
        const mime = mimeTypes[ext] || "text/plain; charset=utf-8";
        res.writeHead(200, { "Content-Type": mime });
        res.end(data);
    });
});


// ----------------------------------------------------
// 2. WebSocket 서버
// ----------------------------------------------------
const wss = new WebSocket.Server({ server: httpServer });

// 전체 접속
const clients = new Set();
// 닉네임 → 소켓
const playerSockets = new Map();
// 소켓 → 컨텍스트
const socketContexts = new Map();
// 방 ID → room
/*
room: {
  id, name, maxPlayers,
  players:Set<nick>,
  host,
  inGame,                // 본게임 진행 여부
  phase,                 // "WAIT" | "PROMPT" | "PLAY"
  words:Map<nick,word>,  // 각 플레이어가 맞혀야 할 제시어 (그 사람 머리 위 단어)
  finished:Set<nick>,
  ready:Set<nick>,
  turnOrder:[],
  turnIndex,
  currentTarget,
  startTime,
  timer,                 // 15분 전체 타이머
  forbiddenWords:[],
  guessedThisTurn:Set<nick>,
  timeViolations:Map<nick,count>,
  askTimer,
  ansTimer,

  // 제시어 단계용
  categoryCode,
  categoryLabel,
  prompts:Map<nick,{target,word}>
}
*/
const rooms = new Map();
let nextRoomId = 1;

// 제시어 카테고리 정의 (랜덤 선택용)
const CATEGORY_LIST = [
  { code: "KR_STAR", label: "한국 연예인 이름" },
  { code: "EN_STAR", label: "외국 배우 / 셀럽 이름" },
  { code: "GAME_CHAR", label: "게임 캐릭터 이름" },
  { code: "ANIME_CHAR", label: "애니메이션 캐릭터 이름" },
];

// ----------------------------------------------------
// 공통 유틸
// ----------------------------------------------------
function sendToSocket(ws, msg) {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(msg);
  }
}
function broadcastToAll(msg) {
  console.log("[GLOBAL]", msg);
  for (const c of clients) sendToSocket(c, msg);
}
function sendToNickname(nick, msg) {
  const sock = playerSockets.get(nick);
  if (sock) sendToSocket(sock, msg);
}
function getContext(ws) {
  return socketContexts.get(ws);
}
function getRoom(roomId) {
  return rooms.get(roomId);
}
function getRoomOfNickname(nickname) {
  for (const room of rooms.values()) {
    if (room.players.has(nickname)) return room;
  }
  return null;
}
function roomBroadcast(room, msg) {
  console.log(`[ROOM ${room.id}]`, msg);
  for (const nick of room.players) {
    sendToNickname(nick, msg);
  }
}

// 방 리스트 브로드캐스트
function broadcastRoomListToAll() {
  const list = [];
  for (const room of rooms.values()) {
    const status = room.inGame ? "INGAME" : "WAIT";
    list.push(
      `${room.id},${room.name},${room.players.size}/${room.maxPlayers},${status}`
    );
  }
  broadcastToAll("ROOM_LIST|" + list.join(";"));
}

// 방 안 유저 리스트
function updateRoomUserList(room) {
  const parts = [];
  for (const nick of room.players) {
    const isHost = room.host === nick;
    const ready = room.ready.has(nick);
    parts.push(`${nick},${ready ? 1 : 0},${isHost ? 1 : 0}`);
  }
  roomBroadcast(room, "ROOM_USER_LIST|" + parts.join(";"));
}

// 방에서 플레이어 제거
function removePlayerFromRoom(nickname) {
  const room = getRoomOfNickname(nickname);
  if (!room) return;

  room.players.delete(nickname);
  room.words.delete(nickname);
  room.finished.delete(nickname);
  room.ready.delete(nickname);
  if (room.guessedThisTurn) room.guessedThisTurn.delete(nickname);
  if (room.timeViolations) room.timeViolations.delete(nickname);
  if (room.prompts) room.prompts.delete(nickname);

  room.turnOrder = room.turnOrder.filter((n) => n !== nickname);

  // 방장 나감 → 인계 또는 (아무도 없으면) 방만 리셋
  if (room.host === nickname) {
    if (room.players.size > 0) {
      const newHost = Array.from(room.players)[0];
      room.host = newHost;
      roomBroadcast(room, "HOST_CHANGE|" + newHost);
      roomBroadcast(room, "SYSTEM|" + newHost + " 님이 새로운 방장이 되었습니다.");
    } else {
      // ★ 방은 삭제하지 않고 초기 상태로 리셋
      if (room.timer) clearTimeout(room.timer);
      if (room.askTimer) clearTimeout(room.askTimer);
      if (room.ansTimer) clearTimeout(room.ansTimer);

      room.inGame = false;
      room.phase = "WAIT";
      room.words.clear();
      room.finished.clear();
      room.ready.clear();
      room.turnOrder = [];
      room.turnIndex = 0;
      room.currentTarget = null;
      room.startTime = null;
      room.categoryCode = null;
      room.categoryLabel = null;
      if (room.prompts) room.prompts.clear();

      room.host = null; // 다음에 들어오는 사람이 방장이 되도록

      broadcastRoomListToAll();
      return;
    }
  }

  roomBroadcast(room, "SYSTEM|" + nickname + " 님이 방에서 나갔습니다.");
  updateRoomUserList(room);
}

// 금지어 체크
function containsForbidden(room, text) {
  const lower = text.toLowerCase();
  for (const w of room.forbiddenWords) {
    if (!w) continue;
    if (lower.includes(w.toLowerCase())) return true;
  }
  return false;
}

// ----------------------------------------------------
// 시간 제한 관련 유틸 (질문 30초 / 답변 30초)
// ----------------------------------------------------
function clearAskTimer(room) {
  if (room.askTimer) {
    clearTimeout(room.askTimer);
    room.askTimer = null;
  }
}
function clearAnsTimer(room) {
  if (room.ansTimer) {
    clearTimeout(room.ansTimer);
    room.ansTimer = null;
  }
}

function addTimeViolation(room, nickname, phase) {
  const prev = room.timeViolations.get(nickname) || 0;
  const next = prev + 1;
  room.timeViolations.set(nickname, next);

  const phaseText = phase === "ASK" ? "질문" : "답변";

  if (next < 3) {
    roomBroadcast(
      room,
      `SYSTEM|${nickname} 님이 ${phaseText} 시간(60초)을 초과했습니다. 경고 ${next}회.`
    );
    sendToNickname(nickname, `TIME_WARN|${phase}|${next}`);
  } else {
    roomBroadcast(
      room,
      `SYSTEM|${nickname} 님이 시간 초과 3회로 패배 처리됩니다.`
    );
    room.finished.add(nickname);
    sendToNickname(nickname, `TIME_LOSE|${phase}|${next}`);

    let allFinished = true;
    for (const p of room.players) {
      if (!room.finished.has(p)) {
        allFinished = false;
        break;
      }
    }
    if (allFinished) {
      room.inGame = false;
      roomBroadcast(room, "GAME_OVER|ALL_CLEAR");
      roomBroadcast(
        room,
        "SYSTEM|모든 플레이어가 정답 또는 시간초과로 게임을 종료합니다."
      );
      if (room.timer) clearTimeout(room.timer);
      clearAskTimer(room);
      clearAnsTimer(room);
    } else {
      nextTurn(room);
    }
  }
}

function startAskTimer(room, nickname) {
  clearAskTimer(room);
  room.askTimer = setTimeout(() => {
    if (!room.inGame) return;
    if (room.turnOrder[room.turnIndex] !== nickname) return;
    addTimeViolation(room, nickname, "ASK");
  }, 60 * 1000);
}

function startAnsTimer(room, nickname) {
  clearAnsTimer(room);
  room.ansTimer = setTimeout(() => {
    if (!room.inGame) return;
    if (room.currentTarget !== nickname) return;
    addTimeViolation(room, nickname, "ANS");
  }, 60 * 1000);
}

// ----------------------------------------------------
// 게임 시작 관련: 제시어 단계 → 본게임 단계
// ----------------------------------------------------

// 1단계: 제시어 입력 단계 시작
function startPromptPhase(room) {
  if (room.players.size < 2) {
    roomBroadcast(room, "SYSTEM|2명 이상일 때만 시작 가능합니다.");
    return;
  }

  // 준비 여부 확인 (기존 규칙 유지)
  for (const nick of room.players) {
    if (!room.ready.has(nick)) {
      roomBroadcast(room, "SYSTEM|모든 플레이어가 준비를 눌러야 시작할 수 있습니다.");
      return;
    }
  }

  room.inGame = false;
  room.phase = "PROMPT";
  room.words.clear();
  room.finished.clear();
  room.guessedThisTurn = new Set();
  room.timeViolations = new Map();
  room.prompts = new Map();
  clearAskTimer(room);
  clearAnsTimer(room);

  // 카테고리 랜덤 선택
  const idx = Math.floor(Math.random() * CATEGORY_LIST.length);
  const cat = CATEGORY_LIST[idx];
  room.categoryCode = cat.code;
  room.categoryLabel = cat.label;

  // 클라이언트에게 제시어 카테고리 알림
  roomBroadcast(room, `CATEGORY|${cat.code}|${cat.label}`);
  roomBroadcast(
    room,
    "SYSTEM|이번 라운드 제시어 카테고리는 '" +
      cat.label +
      "' 입니다. 서로의 제시어를 정해 주세요."
  );
}

// 2단계: 실제 게임 시작 (모든 제시어가 세팅된 후 호출)
function startGamePlay(room) {
  room.phase = "PLAY";
  room.inGame = true;
  room.guessedThisTurn = new Set();
  clearAskTimer(room);
  clearAnsTimer(room);

  // 턴 순서: 닉네임 순 정렬
  room.turnOrder = Array.from(room.players);
  room.turnOrder.sort();
  room.turnIndex = 0;
  room.currentTarget = null;

  // 각 플레이어에게 "본인이 맞혀야 할 단어를 빼고" 나머지 목록 전송
  for (const me of room.players) {
    const sb = [];
    for (const [nick, word] of room.words.entries()) {
      if (nick !== me) {
        sb.push(`${nick}:${word}`);
      }
    }
    sendToNickname(me, "WORDLIST|" + sb.join(";"));
  }

  roomBroadcast(room, "SYSTEM|게임을 시작합니다!");
  roomBroadcast(room, "GAME_START");
  const first = room.turnOrder[room.turnIndex];
  roomBroadcast(room, "TURN|" + first);
  roomBroadcast(room, "ROUND|60|1");


    if (isBotNickname(first)) {
        handleBotTurn(room, first).catch(console.error);
    } else {
        startAskTimer(room, first);
    }

  // 전체 게임 시간 15분
  room.startTime = Date.now();
  if (room.timer) clearTimeout(room.timer);
  room.timer = setTimeout(() => {
    if (room.inGame) {
      room.inGame = false;
      clearAskTimer(room);
      clearAnsTimer(room);
      roomBroadcast(room, "GAME_OVER|TIMEOUT");
      roomBroadcast(
        room,
        "SYSTEM|15분 내에 맞추지 못해 게임에서 패배했습니다."
      );
    }
  }, 15 * 60 * 1000);
}

// 턴 넘기기
function nextTurn(room) {
    if (!room.inGame) return;
    if (room.turnOrder.length === 0) return;

    clearAskTimer(room);
    clearAnsTimer(room);
    if (!room.guessedThisTurn) room.guessedThisTurn = new Set();
    room.guessedThisTurn.clear();

    if (!room.askedThisTurn) room.askedThisTurn = new Set();
    room.askedThisTurn.clear();

    for (let i = 0; i < room.turnOrder.length; i++) {
        room.turnIndex = (room.turnIndex + 1) % room.turnOrder.length;
        const candidate = room.turnOrder[room.turnIndex];
        if (!room.finished.has(candidate)) {
            room.currentTarget = null;
            roomBroadcast(room, "TURN|" + candidate);
            roomBroadcast(room, "ROUND|60|1");

            if (isBotNickname(candidate)) {
                handleBotTurn(room, candidate).catch(console.error);
            } else {
                startAskTimer(room, candidate);
            }
            return;
        }
    }

    room.inGame = false;
    roomBroadcast(room, "GAME_OVER|ALL_CLEAR");
    roomBroadcast(
        room,
        "SYSTEM|모든 플레이어가 정답 또는 시간초과로 게임을 종료합니다."
    );
    if (room.timer) clearTimeout(room.timer);
    clearAskTimer(room);
    clearAnsTimer(room);
}




// ----------------------------------------------------
// WebSocket 명령 처리
// ----------------------------------------------------
function handleCommand(ws, line) {
  if (!line) return;
  const ctx = getContext(ws);
  if (!ctx) return;

  const parts = line.split("|");
  const cmd = parts[0];

  // JOIN: 닉네임 설정
  if (cmd === "JOIN") {
    const rawNick = (parts[1] || "").trim();

    if (!rawNick) {
      sendToSocket(ws, "SYSTEM|닉네임이 비어 있습니다.");
      ws.close();
      return;
    }

    // 이미 존재하는 닉네임이면 _1, _2 ... 붙여서 유니크하게 만듦
    let finalNick = rawNick;
    let suffix = 1;
    while (playerSockets.has(finalNick)) {
      finalNick = `${rawNick}_${suffix++}`;
    }

    ctx.nickname = finalNick;
    ctx.roomId = null;
    playerSockets.set(finalNick, ws);

    // 클라이언트에게 최종 닉네임 알림
    sendToSocket(ws, "NICK_OK|" + finalNick);
    sendToSocket(ws, "SYSTEM|닉네임 설정 완료. 방 리스트를 불러오세요.");
    broadcastRoomListToAll();
    return;
  }

  const nickname = ctx.nickname;
  if (!nickname) {
    sendToSocket(ws, "SYSTEM|먼저 닉네임을 설정하세요.");
    return;
  }

  switch (cmd) {
    case "ROOM_LIST_REQ": {
      broadcastRoomListToAll();
      break;
    }

    case "CREATE_ROOM": {
      const name = parts[1] || "방";
      const maxPlayers = parseInt(parts[2], 10) || 4;
      const id = String(nextRoomId++);

      const room = {
        id,
        name,
        maxPlayers,
        players: new Set(),
        host: nickname,
        inGame: false,
        phase: "WAIT",
        winner: null,
        words: new Map(),
        finished: new Set(),
        ready: new Set(),
        turnOrder: [],
        turnIndex: 0,
        currentTarget: null,
        startTime: null,
        timer: null,
        forbiddenWords: ["첫글자", "초성", "이름 앞글자"],
        guessedThisTurn: new Set(),
        askedThisTurn: new Set(),
        timeViolations: new Map(),
        askTimer: null,
        ansTimer: null,
        categoryCode: null,
        categoryLabel: null,
        prompts: new Map(),
      };

      rooms.set(id, room);
      room.players.add(nickname);
      ctx.roomId = id;

      sendToSocket(ws, "ROOM_CREATED|" + id);
      roomBroadcast(room, "SYSTEM|" + nickname + " 님이 방을 생성했습니다.");
      updateRoomUserList(room);
      broadcastRoomListToAll();
      break;
    }

    case "JOIN_ROOM": {
        const roomId = parts[1];
        const room = getRoom(roomId);

        if (!room) {
            sendToSocket(ws, "SYSTEM|존재하지 않는 방입니다.");
            return;
        }

        // 이미 방 인원에 있는 닉네임인지 체크
        const alreadyInRoom = room.players.has(nickname);

        if (!alreadyInRoom) {
            // 새로 들어오는 사람에 대해서만 인원/게임중 체크
            if (room.players.size >= room.maxPlayers) {
                sendToSocket(ws, "SYSTEM|이미 인원이 가득 찬 방입니다.");
                return;
            }
            if (room.inGame || room.phase === "PLAY") {
                sendToSocket(ws, "SYSTEM|이미 게임 중인 방입니다.");
                return;
            }

            // 새 입장 처리
            room.players.add(nickname);
            ctx.roomId = roomId;

            if (!room.host) {
                room.host = nickname;
                roomBroadcast(room, "HOST_CHANGE|" + nickname);
            }

            roomBroadcast(room, "SYSTEM|" + nickname + " 님이 방에 입장했습니다.");
            updateRoomUserList(room);
            broadcastRoomListToAll();

            sendToSocket(ws, "JOIN_ROOM_OK|" + roomId);
            sendToSocket(ws, "SYSTEM|제시어를 입력하고 준비를 눌러주세요.");
        } else {
            // 이미 방에 속해 있던 닉(= waiting → game.html 같은 경우)
            ctx.roomId = roomId;
            // 그냥 현재 상태만 보내주기
            updateRoomUserList(room);
            // 게임이 이미 PLAY라면, 카테고리/턴 정보도 한 번 더 보내주면 좋음 (선택)
            if (room.categoryCode && room.categoryLabel) {
                sendToSocket(ws, `CATEGORY|${room.categoryCode}|${room.categoryLabel}`);
            }
            const currentTurn = room.turnOrder[room.turnIndex];
            if (currentTurn) {
                sendToSocket(ws, "TURN|" + currentTurn);
            }
        }
        break;
    }

    case "LEAVE_ROOM": {
      const roomId = ctx.roomId;
      if (!roomId) {
        sendToSocket(ws, "SYSTEM|현재 어떤 방에도 속해 있지 않습니다.");
        return;
      }
      ctx.roomId = null;
      removePlayerFromRoom(nickname);
      broadcastRoomListToAll();
      sendToSocket(ws, "LEAVE_ROOM_OK");
      break;
    }

    // (이전: WORD = 자기 제시어) → 필요하면 사용
    case "WORD": {
      const word = parts.slice(1).join("|");
      const room = getRoomOfNickname(nickname);
      if (!room) {
        sendToSocket(ws, "SYSTEM|방에 들어간 후에 제시어를 설정할 수 있습니다.");
        return;
      }
      room.words.set(nickname, word);
      sendToSocket(ws, "SYSTEM|당신의 제시어가 '" + word + "' 로 설정되었습니다.");
      break;
    }

    // READY 토글
    case "READY": {
        const v = parts[1];
        const val = v === "1" || v === "true";   // 1 이나 true 면 준비 ON
        const room = getRoomOfNickname(nickname);
        if (!room) {
            sendToSocket(ws, "SYSTEM|방 안에서만 준비를 설정할 수 있습니다.");
            return;
        }
        if (val) room.ready.add(nickname);
        else room.ready.delete(nickname);
        updateRoomUserList(room);
        break;
    }


    // 방장: 게임 시작 → 제시어 단계로 진입
    case "START_GAME": {
      const room = getRoomOfNickname(nickname);
      if (!room) {
        sendToSocket(ws, "SYSTEM|방 안에서만 게임을 시작할 수 있습니다.");
        return;
      }
      if (room.host !== nickname) {
        sendToSocket(ws, "SYSTEM|방장만 게임을 시작할 수 있습니다.");
        return;
      }
        // ★ 이미 본게임(PLAY) 중이면 다시 시작 못 하게 막기
        if (room.inGame || room.phase === "PLAY") {
            sendToSocket(ws, "SYSTEM|이미 게임이 진행 중입니다.");
            return;
        }
      startPromptPhase(room);
      break;
    }

    // 강퇴
    case "KICK": {
      const target = parts[1];
      const room = getRoomOfNickname(nickname);
      if (!room) {
        sendToSocket(ws, "SYSTEM|방 안에서만 사용할 수 있습니다.");
        return;
      }
      if (room.host !== nickname) {
        sendToSocket(ws, "SYSTEM|방장만 강제퇴장 시킬 수 있습니다.");
        return;
      }
      if (!room.players.has(target)) {
        sendToSocket(ws, "SYSTEM|해당 플레이어는 이 방에 없습니다.");
        return;
      }
      roomBroadcast(room, "SYSTEM|" + target + " 님이 강제퇴장되었습니다.");
      const targetSock = playerSockets.get(target);
      if (targetSock) {
        const tctx = getContext(targetSock);
        if (tctx) tctx.roomId = null;
        sendToSocket(targetSock, "KICKED");
      }
      removePlayerFromRoom(target);
      broadcastRoomListToAll();
      break;
    }

      case "SET_PROMPT": {
          const room = getRoomOfNickname(nickname);
          if (!room) {
              sendToSocket(ws, "SYSTEM|방 안에서만 제시어를 설정할 수 있습니다.");
              return;
          }
          if (room.phase !== "PROMPT") {
              sendToSocket(ws, "SYSTEM|지금은 제시어 입력 단계가 아닙니다.");
              return;
          }

          // 클라이언트가 보낸 target은 무시하고, word만 받기
          const clientTarget = parts[1]; // 안 쓸 거지만 형식 맞추려고 읽기만 함
          const word = parts.slice(2).join("|");
          if (!word) {
              sendToSocket(ws, "SYSTEM|제시어 내용을 입력하세요.");
              return;
          }

          // ★ 서버에서 진짜 target 계산: 닉네임 정렬 기준 다음 사람
          const realTarget = getNextPlayer(room, nickname);
          if (!realTarget) {
              sendToSocket(ws, "SYSTEM|제시어 대상을 결정할 수 없습니다.");
              return;
          }
          if (realTarget === nickname) {
              sendToSocket(ws, "SYSTEM|자기 자신에게 제시어를 줄 수 없습니다.");
              return;
          }

          // 내가 누구에게 어떤 제시어 줄지 등록 (서버가 정한 target 사용)
          room.prompts.set(nickname, { target: realTarget, word });
          sendToSocket(
              ws,
              "SYSTEM|'" + realTarget + "' 님에게 줄 제시어가 설정되었습니다."
          );
          roomBroadcast(room, "PROMPT_SET|" + nickname);

          // 🔥 봇이 방에 있고 아직 제시어를 안 넣었다면, 여기서 자동으로 한 번 넣어준다
          const botNick = "[BOT]세찬";
          if (room.players.has(botNick) && !room.prompts.has(botNick)) {
              // 사람들 중에서 봇이 제시어 줄 대상 하나 선택 (봇 자신 제외)
              const humanTargets = Array.from(room.players).filter(
                  (p) => p !== botNick
              );
              if (humanTargets.length > 0) {
                  const botTarget =
                      humanTargets[Math.floor(Math.random() * humanTargets.length)];
                  const botWord = pickWordForCategory(room.categoryCode);
                  room.prompts.set(botNick, { target: botTarget, word: botWord });
                  roomBroadcast(room, "PROMPT_SET|" + botNick);
              }
          }

          // 아직 제시어 안 넣은 사람 목록 계산해서 방송
          const waiting = [];
          for (const p of room.players) {
              if (!room.prompts.has(p)) waiting.push(p);
          }
          roomBroadcast(room, "PROMPT_STATUS|" + waiting.join(","));

          // 모두 제시어 입력 완료됐는지 확인
          if (room.prompts.size === room.players.size) {
              // target 기준으로 words 채우기
              room.words = new Map();
              console.log(`[ROOM ${room.id}] ==== PROMPT MAPPING ====`);
              for (const [from, data] of room.prompts.entries()) {
                  room.words.set(data.target, data.word);
                  console.log(
                      `[ROOM ${room.id}] ${from} -> ${data.target} : ${data.word}`
                  );
              }
              console.log(`[ROOM ${room.id}] =========================`);

              // 마지막으로 waiting 비우는 브로드캐스트 한 번 더 (선택)
              roomBroadcast(room, "PROMPT_STATUS|");

              roomBroadcast(
                  room,
                  "SYSTEM|모든 제시어 입력이 완료되었습니다. 게임을 시작합니다."
              );
              startGamePlay(room);
          }
          break;
      }


    // ASK
    case "ASK": {
      const room = getRoomOfNickname(nickname);
      if (!room || !room.inGame || room.phase !== "PLAY") {
        sendToSocket(ws, "SYSTEM|게임 중인 방 안에서만 질문할 수 있습니다.");
        return;
      }
      const to = parts[1];
      const q = parts.slice(2).join("|");
      if (!room.players.has(to)) {
        sendToSocket(ws, "SYSTEM|해당 플레이어는 이 방에 없습니다.");
        return;
      }
      if (room.turnOrder[room.turnIndex] !== nickname) {
        sendToSocket(ws, "SYSTEM|지금은 당신의 턴이 아닙니다.");
        return;
      }
      if (containsForbidden(room, q)) {
        sendToSocket(ws, "SYSTEM|금지어를 사용했습니다. 다시 작성해주세요.");
        return;
          }
      if (!room.askedThisTurn) room.askedThisTurn = new Set();
      if (room.askedThisTurn.has(nickname)) {
          sendToSocket(ws, "SYSTEM|이번 턴에는 이미 질문을 한 번 했습니다. 답변을 기다려 주세요.");
          return;
      }
      if (room.currentTarget) {
          sendToSocket(ws, "SYSTEM|이전 질문에 대한 답변이 끝날 때까지 기다려 주세요.");
          return;
      }
      room.askedThisTurn.add(nickname);

      clearAskTimer(room);
      room.currentTarget = to;
      roomBroadcast(room, "ASK|" + nickname + "|" + to + "|" + q);
      roomBroadcast(room, "ROUND|60|1");
      
    if (isBotNickname(to)) {
        // ★ 사람이 봇에게 질문한 경우 → AI 답변
        makeBotAnswer(room, to, nickname, q)
            .then((ans) => {
                roomBroadcast(room, "ANS|" + to + "|" + ans);
                roomBroadcast(room, "ROUND|60|1");
                nextTurn(room);
            })
            .catch((e) => {
                console.error("[bot] answer error:", e);
                roomBroadcast(room, "ANS|" + to + "|(AI 연결 오류).");
                nextTurn(room);
            });
    } else {
        // 사람에게 질문이면 기존처럼 타이머만
        startAnsTimer(room, to);
    }
      break;
    }

    // ANS
    case "ANS": {
      const room = getRoomOfNickname(nickname);
      if (!room || !room.inGame || room.phase !== "PLAY") {
        sendToSocket(ws, "SYSTEM|게임 중인 방 안에서만 답변할 수 있습니다.");
        return;
      }
      const answer = parts.slice(1).join("|");
      if (room.currentTarget !== nickname) {
        sendToSocket(ws, "SYSTEM|지금은 당신이 답변할 차례가 아닙니다.");
        return;
      }
      if (containsForbidden(room, answer)) {
        sendToSocket(ws, "SYSTEM|금지어를 사용했습니다. 다시 작성해주세요.");
        return;
      }

      clearAnsTimer(room);
      roomBroadcast(room, "ANS|" + nickname + "|" + answer);
      roomBroadcast(room, "ROUND|60|1");
      room.currentTarget = null;
      nextTurn(room);
      break;
    }

    // GUESS
    case "GUESS": {
      const room = getRoomOfNickname(nickname);
      if (!room || !room.inGame || room.phase !== "PLAY") {
        sendToSocket(ws, "SYSTEM|게임 중인 방 안에서만 추측할 수 있습니다.");
        return;
      }
      if (room.turnOrder[room.turnIndex] !== nickname) {
        sendToSocket(ws, "SYSTEM|지금은 당신의 턴이 아닙니다.");
        return;
      }
      if (!room.guessedThisTurn) room.guessedThisTurn = new Set();
      if (room.guessedThisTurn.has(nickname)) {
        sendToSocket(
          ws,
          "SYSTEM|이번 턴에는 이미 정답을 한 번 시도했습니다. 다음 턴까지 기다려 주세요."
        );
        return;
      }
      room.guessedThisTurn.add(nickname);
      clearAskTimer(room);

        const guess = parts.slice(1).join("|").trim();
        const real = (room.words.get(nickname) || "").trim();
      if (!real) {
        sendToSocket(ws, "SYSTEM|당신의 제시어가 설정되어 있지 않습니다.");
        return;
      }

      if (real === guess) {
        room.finished.add(nickname);
        roomBroadcast(room, "RESULT|CORRECT|" + nickname + "|" + guess);
        db.increaseWin(nickname).catch(console.error);

        // ★ 첫 번째로 맞춘 사람만 winner로 기록
        if (!room.winner) {
            room.winner = nickname;
        }
      } else {
        roomBroadcast(room, "RESULT|WRONG|" + nickname + "|" + guess);
      }

        // 정답/오답 처리 끝난 뒤에

        // 남아 있는 사람(봇 제외) 수 계산
        let alivePlayers = 0;
        for (const p of room.players) {
            if (!isBotNickname(p) && !room.finished.has(p)) {
                alivePlayers++;
            }
        }

        if (alivePlayers <= 1) {
            // 사람 기준으로 0명 또는 1명만 남으면 게임 종료
            room.inGame = false;

            const winnerName = room.winner || "";
            roomBroadcast(room, "GAME_OVER|ALL_CLEAR|" + winnerName);
            roomBroadcast(
                room,
                "SYSTEM|마지막 남은 플레이어까지 결정되어 게임을 종료합니다."
            );
            if (room.timer) clearTimeout(room.timer);
        } else {
            nextTurn(room);
        }

        break;
      }

    // 🔥 새 프로토콜: 중앙 질문/답변/정답 채팅 (game.js에서 GAME_ACTION 전송)
    // 형식: GAME_ACTION|mode|fromNick|toNick|message
      case "GAME_ACTION": {
          const room = getRoomOfNickname(nickname);
          if (!room) {
              sendToSocket(ws, "SYSTEM|방 안에서만 사용할 수 있습니다.");
              return;
          }

          const mode = parts[1] || "ask"; // ask / ans / guess
          const toNick = parts[3] || "";
          const body = parts.slice(4).join("|");

          if (!body) {
              sendToSocket(ws, "SYSTEM|내용을 입력해주세요.");
              return;
          }

          let tag = "";
          if (mode === "ask") tag = "질문";
          else if (mode === "ans") tag = "답변";
          else if (mode === "guess") tag = "정답";
          else tag = mode;

          // ★ 여기서 우리가 원하는 포맷으로 줄을 만든다
          let line = "";
          if (mode === "ask") {
              // 질문: [질문] 준호 -> ohk: 내용
              line = `[${tag}] ${nickname} → ${toNick || "-"}: ${body}`;
          } else if (mode === "ans") {
              // 답변: [답변] 준호: 내용
              line = `[${tag}] ${nickname}: ${body}`;
          } else if (mode === "guess") {
              // 정답: [정답] 준호: 내용
              line = `[${tag}] ${nickname}: ${body}`;
          }

          // 같은 방의 "다른 사람"에게만 QA_CHAT 브로드캐스트
          for (const p of room.players) {
              //if (p === nickname) continue;
              sendToNickname(p, "QA_CHAT|" + nickname + "|" + line);
          }

          break;
      }


    // 🔥 새 프로토콜: 전체 채팅 (game.js에서 GLOBAL_CHAT 전송)
    // 형식: GLOBAL_CHAT|fromNick|message
    case "GLOBAL_CHAT": {
      const room = getRoomOfNickname(nickname);
      const msg = parts.slice(2).join("|");

      if (!room) {
        sendToSocket(ws, "SYSTEM|방 안에서만 전체 채팅을 사용할 수 있습니다.");
        return;
      }
      if (!msg) {
        sendToSocket(ws, "SYSTEM|채팅 내용을 입력해 주세요.");
        return;
      }

      // 내 화면은 game.js에서 append하므로, 다른 사람에게만 전송
      for (const p of room.players) {
        if (p === nickname) continue;
        sendToNickname(p, "GLOBAL_CHAT|" + nickname + "|" + msg);
      }

      break;
    }

    // 기존 CHAT (필요하면 대기실/기타에서 사용)
    case "CHAT": {
      const room = getRoomOfNickname(nickname);
      const msg = parts.slice(1).join("|");
      if (!room) {
        broadcastToAll("CHAT|" + nickname + "|" + msg);
        return;
      }
      roomBroadcast(room, "CHAT|" + nickname + "|" + msg);
      break;
    }

      case "ADD_BOT": {
          const room = getRoomOfNickname(nickname);
          if (!room) {
              sendToSocket(ws, "SYSTEM|방 안에서만 봇을 추가할 수 있습니다.");
              return;
          }
          if (room.host !== nickname) {
              sendToSocket(ws, "SYSTEM|방장만 봇을 추가할 수 있습니다.");
              return;
          }
          if (room.players.size >= room.maxPlayers) {
              sendToSocket(ws, "SYSTEM|이미 인원이 가득 찼습니다.");
              return;
          }

          const botNick = "[BOT]세찬";
          room.players.add(botNick);
          room.ready.add(botNick);
          // 소켓은 없지만, words/finished/ready 등은 사람과 똑같이 관리
          updateRoomUserList(room);
          roomBroadcast(room, "SYSTEM|봇 '" + botNick + "' 이(가) 방에 추가되었습니다.");
          break;
      }



    default: {
      sendToSocket(ws, "SYSTEM|알 수 없는 명령: " + cmd);
    }
  }
}

async function handleBotTurn(room, botNick) {
    try {
        // 1) 사람들 중에서 질문 대상 하나 고르기 (봇 자신 제외)
        const targets = Array.from(room.players).filter((p) => !isBotNickname(p));
        if (targets.length === 0) return; // 사람이 없으면 종료
        const target = targets[Math.floor(Math.random() * targets.length)];

        // 2) (지금은 히스토리 안 쓰니까) 빈 문자열로 질문 생성
        const historyText = "";
        const question = await makeBotQuestion(historyText);

        // 3) 현재 답변해야 할 대상 기록
        room.currentTarget = target;

        // 4) 방에 질문 브로드캐스트
        roomBroadcast(room, "ASK|" + botNick + "|" + target + "|" + question);
        roomBroadcast(room, "ROUND|60|1");
        // 5) 사람에게 답변 타이머 시작
        startAnsTimer(room, target);
    } catch (e) {
        console.error("[bot] question error:", e);
        roomBroadcast(room, "ANS|" + botNick + "|(AI 연결 오류).");
        nextTurn(room);
    }
}
function getNextPlayer(room, from) {
    const sorted = Array.from(room.players).sort();
    const idx = sorted.indexOf(from);
    if (idx === -1) return null;
    const nextIdx = (idx + 1) % sorted.length;
    return sorted[nextIdx];
}
function isBotNickname(nick) {
    return typeof nick === "string" && nick.startsWith("[BOT]");
}

// ----------------------------------------------------
// WebSocket 이벤트
// ----------------------------------------------------
wss.on("connection", (ws) => {
  console.log("새 클라이언트 접속");
  clients.add(ws);
  socketContexts.set(ws, { nickname: null, roomId: null });

  sendToSocket(ws, "SYSTEM|서버에 연결되었습니다. 닉네임을 입력해주세요.");

  ws.on("message", (data) => {
    const line = data.toString().trim();
    if (line) handleCommand(ws, line);
  });

  ws.on("close", () => {
    console.log("클라이언트 연결 종료");
    const ctx = getContext(ws);
    if (ctx) {
      const nickname = ctx.nickname;
      if (nickname) {
        //removePlayerFromRoom(nickname);
        playerSockets.delete(nickname);
      }
      socketContexts.delete(ws);
    }
    clients.delete(ws);
    broadcastRoomListToAll();
  });

  ws.on("error", (err) => {
    console.log("소켓 에러:", err.message);
  });
});

// ----------------------------------------------------
// 서버 시작
// ----------------------------------------------------
httpServer.listen(PORT, () => {
  console.log("양세찬 게임 웹 서버 시작: http://localhost:" + PORT);
});