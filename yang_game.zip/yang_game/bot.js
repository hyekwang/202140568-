﻿// bot.js
// ======================= 봇 / Gemini 전용 모듈 =========================

require("dotenv").config();
const { GoogleGenerativeAI } = require("@google/generative-ai");

// 1) API 키 / 클라이언트 초기화
const API_KEY = process.env.GEMINI_API_KEY;
console.log("[bot.js] GEMINI_API_KEY length:", API_KEY?.length);

const genAI = new GoogleGenerativeAI(API_KEY);

// 질문/답변에 사용할 모델 (텍스트 전용이면 Flash 계열이면 충분)
const questionModel = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });
const answerModel = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });

// =================== 카테고리별 제시어 후보 ===================

const CATEGORY_WORDS = {
    KR_STAR: [
        "아이유",
        "유재석",
        "박보검",
        "손예진",
        "정우성",
        "김혜수",
        "송중기",
        "김동현",
        "수지",
        "김종국",
    ],
    EN_STAR: [
        "톰 홀랜드",
        "톰 크루즈",
        "스칼렛 요한슨",
        "라이언 레이놀즈",
        "엠마 스톤",
        "크리스 에반스",
        "로버트 다우니 주니어",
        "브래드 피트",
        "레오나르도 디카프리오",
        "밀라 요보비치",
    ],
    GAME_CHAR: [
        "마리오",
        "리신",
        "겐지",
        "트레이서",
        "케인",
        "티모",
        "피카츄",
        "링크",
        "소닉",
        "루이지",
    ],
    ANIME_CHAR: [
        "나루토",
        "손오공",
        "루피",
        "탄지로",
        "코난",
        "이누야샤",
        "도라에몽",
        "짱구",
        "네즈코",
        "조로",
    ],
};

function pickWordForCategory(categoryCode) {
    const list = CATEGORY_WORDS[categoryCode] || [];
    if (!list.length) return "알 수 없는 인물";
    const idx = Math.floor(Math.random() * list.length);
    return list[idx];
}

// =================== 동물 제시어 (예전 함수, 원하면 사용) ===================

async function pickRandomAnimalWordForPlayer(ownerNick) {
    const prompt = `당신은 한국어 스무고개 게임 출제자입니다. 플레이어 "${ownerNick}"의 머리 위에 붙일 "동물" 제시어를 정하세요.

조건:
- 실제 존재하는 동물 이름 (예: 사자, 코끼리, 펭귄).
- 한국어 한 단어로만 출력.
- 설명, 문장 없이 동물 이름만.

동물 이름:`;

    try {
        const result = await questionModel.generateContent(prompt);
        let text = (result.response.text() || "").trim();

        text = text.split(/\r?\n/)[0].trim();
        text = text.replace(/[^가-힣a-zA-Z0-9\s]/g, " ").split(" ")[0].trim();

        if (!text || text.length < 2) text = "사자";
        return text;
    } catch (e) {
        console.error("[bot.js] pickRandomAnimalWordForPlayer error:", e);
        return "사자";
    }
}

// =================== 2) 봇 질문 생성 ===================

// fallback 질문들 (Gemini 실패 시 랜덤 사용)
const FALLBACK_QUESTIONS = [
    "이 인물은 실존 인물인가요?",
    "이 인물은 한국 사람인가요?",
    "이 인물은 남자입니까?",
    "이 인물은 연예인인가요?",
    "이 인물은 가수인가요?",
    "이 인물은 배우인가요?",
    "이 인물은 예능 프로그램에 자주 출연하나요?",
    "이 인물은 2000년 이후에 유명해졌나요?",
    "이 인물은 애니메이션에 등장하나요?",
    "이 인물은 게임에 등장하나요?",
    "이 인물은 주로 어린이들에게 유명한가요?",
    "이 인물은 스포츠와 관련이 있나요?",
];

async function makeBotQuestion(historyText) {
    const prompt = `당신은 한국어 스무고개 게임 AI 플레이어입니다. 
이번 게임에서 제시어는 "사람 이름 또는 캐릭터 이름"입니다.

지금까지 당신의 제시어에 대한 질문/답변 기록:
${historyText || "아직 질문/답변 기록이 없습니다."}

이제 상대에게 예/아니오 형식으로 대답할 수 있는 좋은 질문 하나를 만들어야 합니다.

규칙:
- 예/아니오(또는 비슷한 형식)으로 대답 가능한 질문.
- 인물/캐릭터의 특징(한국/외국, 실존 인물인지, 나이대, 분야(가수/배우/운동선수), 출연 작품, 애니/게임/현실 인물 여부 등)을 좁혀가는 질문.
- 한국어 한 문장만 출력.
- "설명, 규칙, 예시" 등을 쓰지 말고, 완성된 질문 문장만 출력.

예시:
- "이 사람은 한국 연예인인가요?"
- "이 인물은 애니메이션에서 등장하나요?"
- "이 캐릭터는 게임에 나오는 캐릭터인가요?"

질문 문장만 출력:`;

    try {
        const result = await questionModel.generateContent(prompt);
        let raw = (result.response.text() || "").trim();

        let lines = raw
            .split(/\r?\n/)
            .map((l) => l.trim())
            .filter(Boolean);

        let line =
            lines.find((l) => l.includes("?")) ||
            lines[0] ||
            "";

        line = line.replace(/^(질문[:：]\s*|Q[:：]\s*)/i, "").trim();

        const metaKeywords = ["이해했습니다", "질문에 대한 답변", "규칙", "형식으로 시작"];
        if (metaKeywords.some((k) => line.includes(k))) {
            line = "";
        }

        if (line && !line.includes("?")) {
            line = line.replace(/[.。!]$/, "");
            line = line + "?";
        }

        if (!line) {
            const idx = Math.floor(Math.random() * FALLBACK_QUESTIONS.length);
            line = FALLBACK_QUESTIONS[idx];
        }

        return line;
    } catch (err) {
        console.error("[bot.js] makeBotQuestion error:", err);
        const idx = Math.floor(Math.random() * FALLBACK_QUESTIONS.length);
        return FALLBACK_QUESTIONS[idx];
    }
}

// =================== 3) 봇이 사람 질문에 답변 생성 ===================

async function makeBotAnswer(word, question) {
    const prompt = `한국어 스무고개 게임 AI 답변자입니다.

머리 위 제시어(사람 이름 또는 캐릭터 이름): "${word}"

플레이어의 질문: "${question}"

규칙:
- "${word}" 기준으로 "예", "아니오", "네", "아니요", "모르겠다" 같은 아주 짧은 한 문장만 출력.
- 설명을 덧붙이지 말고, 딱 한 문장만.
- "답변:" 같은 접두어도 쓰지 마세요.

예시:
- "예."
- "아니요."
- "모르겠습니다."

그 형식으로 한 문장만 출력:`;

    try {
        const result = await answerModel.generateContent(prompt);
        let raw = (result.response.text() || "").trim();

        let lines = raw
            .split(/\r?\n/)
            .map((l) => l.trim())
            .filter(Boolean);

        let line =
            lines.find((l) =>
                /^(예|네|아니오|아니요|모르겠|모르겠다)/.test(l)
            ) ||
            lines[0] ||
            "";

        line = line.replace(/^답변[:：]\s*/i, "").trim();

        const sentenceSplit = line.split(/(?<=[.?!。？！])\s+/);
        if (sentenceSplit[0]) {
            line = sentenceSplit[0].trim();
        }

        if (!line) {
            line = "모르겠습니다.";
        }

        if (!/[.?!]$/.test(line)) line += ".";

        return line;
    } catch (err) {
        console.error("[bot.js] makeBotAnswer error:", err);
        return "모르겠습니다.";
    }
}

// =================== (옵션) 모델 목록 조회 ===================

async function listAvailableModelsOnStart() {
    try {
        if (!API_KEY) {
            console.error(
                "[bot.js] GEMINI_API_KEY가 설정되어 있지 않습니다. 목록 조회 불가."
            );
            return null;
        }
        const url = `https://generativelanguage.googleapis.com/v1beta/models?key=${API_KEY}`;
        const res = await fetch(url);
        if (!res.ok) {
            const txt = await res.text();
            console.error("[bot.js] 모델 목록 조회 실패:", res.status, txt);
            return null;
        }
        const json = await res.json();
        const models = json.models || [];
        console.log(
            "[bot.js] Available Gemini models:",
            models.map((m) => m.name)
        );
        return models;
    } catch (err) {
        console.error("[bot.js] listAvailableModelsOnStart 오류:", err);
        return null;
    }
}

module.exports = {
    pickRandomAnimalWordForPlayer,
    makeBotQuestion,
    makeBotAnswer,
    listAvailableModelsOnStart,
    CATEGORY_WORDS,
    pickWordForCategory,
};
