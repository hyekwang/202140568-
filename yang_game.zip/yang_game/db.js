// db.js
const mysql = require("mysql2/promise");

const pool = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "rootroot",
    database: "yang_game",
    waitForConnections: true,
    connectionLimit: 10,
});

async function findUserById(id) {
    const [rows] = await pool.query("SELECT * FROM users WHERE id = ?", [id]);
    return rows[0] || null;
}
async function findUserByNickname(nickname) {
    const [rows] = await pool.query("SELECT * FROM users WHERE nickname = ?", [nickname]);
    return rows[0] || null;
}
async function createUser({ id, nickname, password }) {
    await pool.query(
        "INSERT INTO users (id, nickname, password, win_count) VALUES (?, ?, ?, 0)",
        [id, nickname, password]
    );
}
async function increaseWin(nickname) {
    await pool.query("UPDATE users SET win_count = win_count + 1 WHERE nickname = ?", [nickname]);
}
async function getWinCount(nickname) {
    const [rows] = await pool.query(
        "SELECT win_count FROM users WHERE nickname = ?",
        [nickname]
    );
    return rows[0] ? rows[0].win_count : 0;
}

module.exports = {
    findUserById,
    findUserByNickname,
    createUser,
    increaseWin,
    getWinCount,
};
