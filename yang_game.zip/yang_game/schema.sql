CREATE DATABASE IF NOT EXISTS yang_game CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

USE yang_game;

CREATE TABLE IF NOT EXISTS users (
  id        VARCHAR(50)  PRIMARY KEY,
  nickname  VARCHAR(50)  NOT NULL UNIQUE,
  password  VARCHAR(100) NOT NULL,
  win_count INT          NOT NULL DEFAULT 0
);